package org.LpDql.MonProjet.imprime_rendu;

import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase {

	public String str;

	@Override
	@Before
	public void setUp() throws Exception {
		str = "";
	}

	@Override
	@After
	public void tearDown() throws Exception {
		str = null;
	}

	@Test
	public void test() {
		App mockobj = Mockito.mock(App.class);
		when(mockobj.imprimante()).thenReturn("Hello it's not the world");
	}

}
