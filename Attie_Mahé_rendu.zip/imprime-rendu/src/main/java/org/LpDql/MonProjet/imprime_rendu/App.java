package org.LpDql.MonProjet.imprime_rendu;

/**
 * Hello world!
 *
 */
public class App {
	public String imprimante() {
		return "Hello World!";
	}
}
